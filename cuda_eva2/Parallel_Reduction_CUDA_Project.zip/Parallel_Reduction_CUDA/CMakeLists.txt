# Alternative build with CMake (3.24+ for automatic GPU detection).
#   cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
#   cmake --build build --config Release
cmake_minimum_required(VERSION 3.24)

# "native" = compile for the GPU(s) found on this machine. Override with
#   -DCMAKE_CUDA_ARCHITECTURES=86   (for example)
if(NOT DEFINED CMAKE_CUDA_ARCHITECTURES)
  set(CMAKE_CUDA_ARCHITECTURES native)
endif()

project(ParallelReductionCUDA LANGUAGES CXX CUDA)

if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
  set(CMAKE_BUILD_TYPE Release)
endif()

add_executable(parallel_reduction src/parallel_reduction.cu)
set_target_properties(parallel_reduction PROPERTIES
  CUDA_STANDARD 17
  CUDA_STANDARD_REQUIRED ON
  CXX_STANDARD 17)
target_compile_options(parallel_reduction PRIVATE
  $<$<COMPILE_LANGUAGE:CUDA>:-lineinfo>)
