# Parallel Reduction in CUDA — CUDA Lab Evaluation, Theme 1

**Team:** Bhoomi Bankapur · Sneha Shettar · Sanket Ullagaddi

## 1. Overview and aim
Add up a very large array (2^24 = 16,777,216 floats) on the GPU, and make the kernel faster by changing how threads cooperate.

**Objectives**
1. Write a CPU reference sum.
2. Write a naive GPU reduction (interleaved addressing, `tid % (2*s) == 0`).
3. Write an optimised GPU reduction (sequential addressing + first add during load + `__shfl_down_sync`).
4. Time all three, compute bandwidth and speedup, and check that all three sums match.
5. Find the best block size on our GPU by experiment.

**Technologies:** CUDA C++ (C++17), NVIDIA CUDA Toolkit / `nvcc`, CUDA events for GPU timing, `std::chrono` for CPU timing, optional CMake.

## 2. Project structure
```
Parallel_Reduction_CUDA/
├── src/parallel_reduction.cu      all code: CPU reference, 2 kernels, multi-pass driver, benchmark
├── results/results_template.csv   column layout of the CSV the program writes (values PENDING)
├── scripts/build_linux.sh         build (+ optional run) on Linux
├── scripts/build_windows.bat      build (+ optional run) on Windows
├── CMakeLists.txt                 alternative CMake build
└── README.md
```

## 3. How the three approaches work
| Approach | Idea |
|---|---|
| **CPU** | One loop adds all elements into a `double` (accurate reference). Timed with `std::chrono` (1 warm-up + 10 runs). |
| **Naive GPU** | Each block copies `blockDim.x` elements into shared memory. At step `s = 1, 2, 4, …` only threads with `tid % (2*s) == 0` do `sdata[tid] += sdata[tid+s]`, followed by `__syncthreads()`. Thread 0 writes the block's partial sum. |
| **Optimised GPU** | (a) Each thread loads **two** elements and adds them during the load (block covers `2*blockDim.x` elements). (b) **Sequential addressing**: `for (s = blockDim/2; s > 32; s >>= 1) if (tid < s) …` — active threads are contiguous. (c) The last 64 values are folded by warp 0 using `__shfl_down_sync(0xffffffff, sum, offset)` with offsets 16, 8, 4, 2, 1 — no shared memory, no `__syncthreads()`. |

**Multiple blocks:** each pass writes one partial sum per block. The host launches the same kernel again on the partial sums (ping-pong buffers) until only one value remains — **all passes run on the GPU and are all inside the timing**. For 2^24 elements at block 256: naive = 3 passes (16,777,216 → 65,536 → 256 → 1), optimised = 3 passes (→ 32,768 → 64 → 1).

**Sizes that are not multiples of the block width** are handled with bounds checks; missing elements are loaded as 0 (the identity of addition). The program self-tests sizes 1, 2, 31, 63, 64, 65, 255, 1000, 4097, 65537 and 1000003 before benchmarking.

## 4. Prerequisites
- Any NVIDIA GPU supported by your installed CUDA Toolkit (warp size 32), with a matching driver.
- CUDA Toolkit 11.6 or newer (for `-arch=native`; older versions fall back automatically).
- Linux: `g++`. Windows: Visual Studio 2019/2022 with "Desktop development with C++".
- About 200 MB of free GPU memory.

## 5. Build
**Linux**
```bash
bash scripts/build_linux.sh            # build only
bash scripts/build_linux.sh --run      # build and run, log saved to results/run_log.txt
```
**Windows** (open *x64 Native Tools Command Prompt for VS*, `cd` into the project folder):
```bat
scripts\build_windows.bat
scripts\build_windows.bat run
```
**Manual nvcc (any OS)**
```bash
nvcc -O3 -std=c++17 -arch=native src/parallel_reduction.cu -o build/parallel_reduction
# If -arch=native is not supported: find the compute capability with
#   nvidia-smi --query-gpu=compute_cap --format=csv,noheader      (e.g. 8.6)
# and use -arch=sm_86 (replace 86 with your value).
```
**CMake (3.24+)**
```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```
The scripts never hard-code a GPU: they try `-arch=native`, then the compute capability reported by `nvidia-smi`, then the toolkit default.

## 6. Run
Run from the project folder (so the CSV lands in `results/`):
```bash
./build/parallel_reduction                 # Linux
build\parallel_reduction.exe               # Windows
```
Options:
```
--n N          number of floats (default 16777216 = 2^24)
--block B      block size for the main table (power of 2, >= 64; default 256)
--iters K      timed iterations (default 30)   --warmup W   warm-up runs (default 5)
--seed S       data seed (default 2024)        --csv FILE   output CSV path
--no-sweep     skip the block-size experiment  --no-selftest skip edge-size tests
```

## 7. Reading the output
1. **Device block** — GPU name, compute capability, SMs, shared memory, theoretical peak bandwidth. Copy the GPU name and CC to Slide 5.
2. **[1] Edge-case test** — must say `ALL PASS`.
3. **[2] CPU reference** — sum and time. With the default seed the CPU sum is **8386194.438598** on every machine (deterministic data).
4. **[3] Results table** — time (ms), effective bandwidth (GB/s), speedup, final sum, relative error, Match. → **Slide 5 table.**
5. **[4] Block-size experiment** — naive and optimised times for 128/256/512/1024 and the **best block size** for each. → **Slide 6 chart.**
6. `results/benchmark_results.csv` — same numbers, ready for Excel / the slide charts.
7. Last line: `OVERALL CORRECTNESS: PASS`. Exit code is 0 on success, 1 on any mismatch.

## 8. Correctness verification
- Reference = CPU sum with a **double** accumulator.
- GPU sum passes if `|gpu − cpu| / |cpu| ≤ 1e-5`.
- Small differences are expected: floating-point addition is not associative, so a different order of additions gives slightly different rounding. A tree sum is actually *more* accurate than a plain sequential float loop (in a CPU simulation of our kernels: tree ≈ 1e-8 relative error, sequential float loop ≈ 2e-5).

## 9. How benchmarking works
- Input generation, `cudaMalloc` and the host→device copy are **outside** the timed region.
- 5 warm-up runs, then 30 timed runs; each run is bracketed by `cudaEventRecord(start/stop)` and **includes every reduction pass**. Average (and min/max in the CSV) is reported.
- **Speedup** = CPU time / GPU time.
- **Effective input bandwidth (GB/s)** = N × 4 bytes / kernel time / 10^9. It counts only reading the input once; the extra reads/writes of partial sums in later passes (< 1 % of the traffic) are excluded.
- **Kernel-only** times are the main result. An **end-to-end** time (host→device copy + kernels + copying back the result, pageable memory) is printed separately for reference — it is dominated by the PCIe copy.

## 10. CUDA concepts used
Thread / block / grid hierarchy · warps (32 threads) · shared memory (`extern __shared__`) · `__syncthreads()` barrier · interleaved vs sequential addressing · warp divergence · shared-memory bank conflicts · warp shuffle `__shfl_down_sync` · multi-pass reduction with partial sums · CUDA events · error checking with `cudaGetLastError` / `cudaGetErrorString` · device queries with `cudaGetDeviceProperties`.

## 11. Evaluation-day checklist
1. Copy the folder to the CUDA workstation, build, run with `--run`.
2. Check `ALL PASS` and `OVERALL CORRECTNESS: PASS`.
3. Fill every **[PENDING GPU RUN]** box on Slides 5 and 6 with numbers from the output / CSV (GPU name, times, GB/s, speedups, sums, best block size). Right-click each chart → *Edit Data* to paste the CSV values.
4. Keep `results/run_log.txt` and `results/benchmark_results.csv` as proof of your own run.

> **Status of this package:** the source compiles without warnings with `nvcc` 13.5 (targets sm_75 and sm_89) and the kernel indexing was checked with a CPU simulation. It has **not** yet been run on an NVIDIA GPU — all performance numbers must come from your own run.
